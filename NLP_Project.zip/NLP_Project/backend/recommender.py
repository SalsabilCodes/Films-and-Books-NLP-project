import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

class Recommender:
    def __init__(self, films_path: str, books_path: str):
        print("Loading model...")
        self.model = SentenceTransformer("all-MiniLM-L6-v2")

        print("Loading films...")
        self.films = self._load(films_path, title_col="Name")

        print("Loading books...")
        self.books = self._load(books_path, title_col="Title")

        print("Encoding films...")
        self.film_vectors = self.model.encode(
            self.films["text"].tolist(), show_progress_bar=True
        )

        print("Encoding books...")
        self.book_vectors = self.model.encode(
            self.books["text"].tolist(), show_progress_bar=True
        )

        print("Ready!")

    def _load(self, path: str, title_col: str) -> pd.DataFrame:
        df = pd.read_csv(path)

        # Drop rows with no description
        df = df[df["Description"].notna() & (df["Description"].str.strip() != "")]
        df = df.reset_index(drop=True)

        # Build a rich text for embedding: genre + description
        df["Genre"] = df["Genre"].fillna("")
        df["text"] = df.apply(
            lambda r: f"{r['Genre']}. {r['Description']}", axis=1
        )

        df["title"] = df[title_col]
        return df

    def recommend(self, mood: str):
        mood_vec = self.model.encode([mood])

        # Films
        film_scores = cosine_similarity(mood_vec, self.film_vectors)[0]
        # Add small randomness to top results so it's not always the exact same pick
        top_film_idx = self._pick_from_top(film_scores, n=5)
        film_row = self.films.iloc[top_film_idx]

        # Books
        book_scores = cosine_similarity(mood_vec, self.book_vectors)[0]
        top_book_idx = self._pick_from_top(book_scores, n=3)
        book_row = self.books.iloc[top_book_idx]

        return self._format(film_row), self._format(book_row)

    def _pick_from_top(self, scores: np.ndarray, n: int) -> int:
        top_n = np.argsort(scores)[-n:]
        return int(np.random.choice(top_n))

    def _format(self, row) -> dict:
        return {
            "title":       str(row.get("title", "")),
            "genre":       str(row.get("Genre", "")),
            "description": str(row.get("Description", "")),
        }
