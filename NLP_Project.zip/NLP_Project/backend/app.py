from flask import Flask, request, jsonify
from flask_cors import CORS
from recommender import Recommender

app = Flask(__name__)
CORS(app)

recommender = Recommender(
    films_path=r"C:\Users\Salsabeel\Dropbox\PC\Downloads\NLP_Project\Films_enriched.csv",
    books_path=r"C:\Users\Salsabeel\Dropbox\PC\Downloads\NLP_Project\Books_enriched.csv",
)

@app.route("/recommend", methods=["POST"])
def recommend():
    data = request.get_json()
    mood = data.get("mood", "").strip()
    if not mood:
        return jsonify({"error": "No mood provided"}), 400

    film, book = recommender.recommend(mood)
    return jsonify({"film": film, "book": book})

@app.route("/health")
def health():
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(debug=True, port=5000)
