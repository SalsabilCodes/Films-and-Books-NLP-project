import requests
import pandas as pd
import time

# ─── CONFIG ───────────────────────────────────────────────────────────────────
INPUT_BOOKS  = r"C:\Users\Salsabeel\Dropbox\PC\Downloads\NLP_Project\Books.csv"
OUTPUT_BOOKS = r"C:\Users\Salsabeel\Dropbox\PC\Downloads\NLP_Project\Books_enriched.csv"
DELAY = 0.3
# ──────────────────────────────────────────────────────────────────────────────


def fetch_book(title: str, author: str):
    clean_title = title.split("(")[0].strip()

    params = {"title": clean_title, "author": author, "limit": 3, "fields": "key,title,subject,first_sentence"}
    r = requests.get("https://openlibrary.org/search.json", params=params, timeout=10)

    if not r.ok or not r.json().get("docs"):
        r = requests.get("https://openlibrary.org/search.json",
                         params={"title": clean_title, "limit": 3,
                                 "fields": "key,title,subject,first_sentence"},
                         timeout=10)

    if not r.ok:
        return "", ""

    docs = r.json().get("docs", [])
    if not docs:
        return "", ""

    doc = docs[0]

    subjects = doc.get("subject", [])
    genres = ", ".join(s for s in subjects[:6] if len(s) < 40)

    first = doc.get("first_sentence", "")
    if isinstance(first, dict):
        first = first.get("value", "")

    description = first
    if not description and doc.get("key"):
        work_url = f"https://openlibrary.org{doc['key']}.json"
        wr = requests.get(work_url, timeout=10)
        if wr.ok:
            wdata = wr.json()
            desc = wdata.get("description", "")
            if isinstance(desc, dict):
                desc = desc.get("value", "")
            description = desc[:800].rsplit(" ", 1)[0] + "..." if len(desc) > 800 else desc
        time.sleep(0.2)

    return genres, description


def enrich_books():
    print("Loading Books.csv ...")
    df = pd.read_csv(INPUT_BOOKS)

    genres_list, descs_list = [], []
    total = len(df)

    for i, row in df.iterrows():
        title  = str(row.get("Title", "")).strip()
        author = str(row.get("Author", "")).strip()

        try:
            genres, desc = fetch_book(title, author)
        except Exception as e:
            print(f"  [{i+1}/{total}] Error on '{title}': {e}")
            genres, desc = "", ""

        genres_list.append(genres)
        descs_list.append(desc)

        status = "OK" if genres or desc else "MISS"
        print(f"  [{i+1}/{total}] {status} {title}")
        time.sleep(DELAY)

    df["Genre"]       = genres_list
    df["Description"] = descs_list
    df.to_csv(OUTPUT_BOOKS, index=False, encoding="utf-8-sig")
    filled = sum(1 for g in genres_list if g)
    print(f"\nDone - {filled}/{total} matched. Saved to {OUTPUT_BOOKS}")


if __name__ == "__main__":
    enrich_books()
