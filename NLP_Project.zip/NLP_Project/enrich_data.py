"""
Enrich Films.csv and Books.csv with Genre and Description.
- Films: uses TMDB API (needs TMDB_API_KEY env var or hardcoded below)
- Books: uses Google Books API (no key needed)

Usage:
    pip install requests pandas
    python enrich_data.py
"""

import requests
import pandas as pd
import time
import os

# ─── CONFIG ───────────────────────────────────────────────────────────────────
TMDB_API_KEY = "49cdb11ea49470cf00e71ed8ee1bac17"   # <-- paste your key here
# Get a free key at: https://www.themoviedb.org/settings/api
# Or set env var:  export TMDB_API_KEY="your_key"

TMDB_API_KEY = os.environ.get("TMDB_API_KEY", TMDB_API_KEY)

INPUT_FILMS  = r"C:\Users\Salsabeel\Dropbox\PC\Downloads\NLP_Project\Films.csv"
INPUT_BOOKS  = r"C:\Users\Salsabeel\Dropbox\PC\Downloads\NLP_Project\Books.csv"
OUTPUT_FILMS = r"C:\Users\Salsabeel\Dropbox\PC\Downloads\NLP_Project\Films_enriched.csv"
OUTPUT_BOOKS = r"C:\Users\Salsabeel\Dropbox\PC\Downloads\NLP_Project\Books_enriched.csv"
DELAY = 0.25   # seconds between API calls (be polite to servers)
# ──────────────────────────────────────────────────────────────────────────────


# ── TMDB helpers ──────────────────────────────────────────────────────────────

TMDB_GENRE_MAP = {}   # filled once on first call

def load_tmdb_genres():
    global TMDB_GENRE_MAP
    url = "https://api.themoviedb.org/3/genre/movie/list"
    r = requests.get(url, params={"api_key": TMDB_API_KEY, "language": "en-US"})
    if r.ok:
        for g in r.json().get("genres", []):
            TMDB_GENRE_MAP[g["id"]] = g["name"]


def fetch_film(title: str, year: str):
    """Search TMDB for a film; return (genres_str, overview)."""
    params = {
        "api_key": TMDB_API_KEY,
        "query": title,
        "language": "en-US",
    }
    if year and str(year).isdigit():
        params["year"] = int(year)

    r = requests.get("https://api.themoviedb.org/3/search/movie", params=params)
    if not r.ok:
        return "", ""

    results = r.json().get("results", [])
    if not results:
        # retry without year constraint
        params.pop("year", None)
        r = requests.get("https://api.themoviedb.org/3/search/movie", params=params)
        results = r.json().get("results", [])

    if not results:
        return "", ""

    hit = results[0]
    genre_ids = hit.get("genre_ids", [])
    genres = ", ".join(TMDB_GENRE_MAP.get(gid, "") for gid in genre_ids if gid in TMDB_GENRE_MAP)
    overview = hit.get("overview", "")
    return genres, overview


# ── Google Books helpers ───────────────────────────────────────────────────────

def fetch_book(title: str, author: str):
    """Search Google Books; return (genres_str, description)."""
    query = f'intitle:"{title}" inauthor:"{author}"'
    r = requests.get(
        "https://www.googleapis.com/books/v1/volumes",
        params={"q": query, "maxResults": 1, "langRestrict": "en"},
    )
    if not r.ok:
        return "", ""

    items = r.json().get("items", [])
    if not items:
        # retry with title only
        r = requests.get(
            "https://www.googleapis.com/books/v1/volumes",
            params={"q": f'intitle:"{title}"', "maxResults": 1},
        )
        items = r.json().get("items", [])

    if not items:
        return "", ""

    info = items[0].get("volumeInfo", {})
    categories = info.get("categories", [])
    genres = ", ".join(categories)
    description = info.get("description", "")
    # trim very long descriptions
    if len(description) > 800:
        description = description[:800].rsplit(" ", 1)[0] + "…"
    return genres, description


# ── Main ──────────────────────────────────────────────────────────────────────

def enrich_films():
    print("📽  Loading Films.csv …")
    df = pd.read_csv(INPUT_FILMS)

    if TMDB_API_KEY == "YOUR_TMDB_API_KEY_HERE":
        print("\n⚠️  TMDB_API_KEY not set!")
        print("   Get a free key at https://www.themoviedb.org/settings/api")
        print("   Then set: export TMDB_API_KEY='your_key'  or edit the script.\n")
        df["Genre"] = ""
        df["Description"] = ""
        df.to_csv(OUTPUT_FILMS, index=False)
        return

    load_tmdb_genres()
    print(f"   Loaded {len(TMDB_GENRE_MAP)} TMDB genres.")

    genres_list, descs_list = [], []
    total = len(df)

    for i, row in df.iterrows():
        title = str(row.get("Name", "")).strip()
        year  = str(row.get("Year", "")).strip()
        genres, desc = fetch_film(title, year)
        genres_list.append(genres)
        descs_list.append(desc)

        status = "✓" if genres or desc else "✗"
        print(f"  [{i+1}/{total}] {status} {title} ({year})")
        time.sleep(DELAY)

    df["Genre"]       = genres_list
    df["Description"] = descs_list
    df.to_csv(OUTPUT_FILMS, index=False)
    filled = sum(1 for g in genres_list if g)
    print(f"\n✅ Films done — {filled}/{total} matched.\n   Saved → {OUTPUT_FILMS}\n")


def enrich_books():
    print("📚  Loading Books.csv …")
    df = pd.read_csv(INPUT_BOOKS)

    genres_list, descs_list = [], []
    total = len(df)

    for i, row in df.iterrows():
        title  = str(row.get("Title", "")).strip()
        author = str(row.get("Author", "")).strip()
        genres, desc = fetch_book(title, author)
        genres_list.append(genres)
        descs_list.append(desc)

        status = "✓" if genres or desc else "✗"
        print(f"  [{i+1}/{total}] {status} {title}")
        time.sleep(DELAY)

    df["Genre"]       = genres_list
    df["Description"] = descs_list
    df.to_csv(OUTPUT_BOOKS, index=False)
    filled = sum(1 for g in genres_list if g)
    print(f"\n✅ Books done — {filled}/{total} matched.\n   Saved → {OUTPUT_BOOKS}\n")


if __name__ == "__main__":
    os.makedirs(os.path.dirname(OUTPUT_FILMS), exist_ok=True)
    enrich_books()   # no key needed, runs first
    enrich_films()   # needs TMDB key
    print("🎉  All done! Check the output files.")
