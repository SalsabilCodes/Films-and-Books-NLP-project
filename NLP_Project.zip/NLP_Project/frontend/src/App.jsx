import { useState } from "react"
import "./App.css"

const MOODS = [
  "I'm energetic and want something funny",
  "I'm in the mood for adventure and excitement",
  "I need something emotional that might make me cry",
]

function Card({ data, type }) {
  if (!data) return null
  const icon = type === "film" ? "🎬" : "📚"
  const label = type === "film" ? "Film" : "Book"

  return (
    <div className={`card card-${type}`}>
      <div className="card-header">
        <span className="card-icon">{icon}</span>
        <span className="card-label">{label}</span>
      </div>
      <h2 className="card-title">{data.title}</h2>
      {data.genre && (
        <div className="card-genres">
          {data.genre.split(",").map((g) => (
            <span key={g} className="genre-tag">{g.trim()}</span>
          ))}
        </div>
      )}
      <p className="card-desc">{data.description}</p>
    </div>
  )
}

export default function App() {
  const [mood, setMood] = useState("")
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  async function handleSubmit() {
    if (!mood.trim()) return
    setLoading(true)
    setError("")
    setResult(null)

    try {
      const res = await fetch("http://localhost:5000/recommend", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mood }),
      })
      if (!res.ok) throw new Error("Server error")
      const data = await res.json()
      setResult(data)
    } catch {
      setError("تعذر الاتصال بالسيرفر. تأكد أن Flask شغال.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="app">
      <header className="app-header">
        <h1 className="app-title">?How are you feeling today</h1>
        <p className="app-subtitle">Tell me what you feel like watching or reading, and I'll recommend a film and a book</p>
      </header>

      <main className="app-main">
        <div className="mood-suggestions">
          {MOODS.map((m) => (
            <button
              key={m}
              className={`mood-chip ${mood === m ? "active" : ""}`}
              onClick={() => setMood(m)}
            >
              {m}
            </button>
          ))}
        </div>

        <div className="input-area">
          <textarea
            className="mood-input"
            placeholder="Example: I'm feeling down and need something to cheer me up"
            value={mood}
            onChange={(e) => setMood(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSubmit()}
            rows={3}
            dir="auto"
          />
          <button
            className={`submit-btn ${loading ? "loading" : ""}`}
            onClick={handleSubmit}
            disabled={loading || !mood.trim()}
          >
            {loading ? (
              <span className="spinner" />
            ) : (
              "✨ Recommend me something "
            )}
          </button>
        </div>

        {error && <p className="error-msg">{error}</p>}

        {result && (
          <div className="results">
            <Card data={result.film} type="film" />
            <Card data={result.book} type="book" />
          </div>
        )}
      </main>
    </div>
  )
}
